# KRD MATH LAB — AI Teacher Backend

This project serves the KRD MATH LAB web app and a secure AI endpoint at `POST /api/solve`.
It supports both typed questions and one uploaded mathematics image (JPG, PNG, WEBP, GIF; max 10 MB).

## Requirements
- Node.js 20 or newer
- An OpenAI API key with API billing/usage enabled

## Run locally
1. Open this folder in a terminal.
2. Install dependencies: `npm install`
3. Copy `.env.example` to `.env`.
4. Put your secret key in `.env` as `OPENAI_API_KEY=...`.
5. Start: `npm start`
6. Open `http://localhost:3000`.

The app already uses `/api/solve`, so it works on the same origin without changing the endpoint setting.

## Deploy (Render / Railway / any Node host)
- Upload this whole project folder to your hosting provider or a private Git repository.
- Runtime: Node.js 20+
- Build command: `npm install`
- Start command: `npm start`
- Add environment variables in the host dashboard:
  - `OPENAI_API_KEY` = your secret API key
  - `OPENAI_MODEL` = `gpt-4.1-mini` (optional)
- Do NOT put the API key in `public/index.html`, browser JavaScript, or a public repository.
- Once deployed, open the app URL. The frontend calls `/api/solve` on the same server.

## Test
- Visit `/api/health`. It should return JSON with `ok: true` and `configured: true` once the key is set.
- Ask a typed math question in AI Math Teacher.
- Upload a clear photo of a math problem and send it.

## Notes
- API usage is billed by OpenAI separately from ChatGPT subscriptions.
- The server limits requests to 20 per minute per IP and image uploads to 10 MB.
- This is a starter deployment. For a public school-wide rollout, add user authentication, stronger abuse protection, and usage budgets.
